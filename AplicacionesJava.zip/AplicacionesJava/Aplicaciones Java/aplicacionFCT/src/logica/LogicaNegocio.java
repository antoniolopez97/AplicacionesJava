/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logica;

import aplicacionFCT.dto.Alumno;
import java.util.ArrayList;
import java.util.List;
import aplicacionFCT.dto.Empresas;
import aplicacionFCT.dto.Usuario;
import java.util.Date;
/**
 *
 * @author AntonioLópezMielgo
 */
public class LogicaNegocio {
     private static List<Alumno> listaAlumno=new ArrayList<>();

    
     private static List<Empresas> listaEmpresa=new ArrayList<>();

     
     
      public static void Mostrar(Alumno alumno ){
        
     listaAlumno.add(alumno);

    }
     
    public static void aniadir(Alumno alumno ){
       
      listaAlumno.add(alumno);
       System.out.println("se añadido un alumno "+alumno.prueba());
    }
     public static void aniadirEmpresa(Empresas empresa ){
    listaEmpresa.add(empresa);
    }

    public static List<Alumno> getListaAlumnos() {
        return listaAlumno;
    }
    public static List<Empresas> getListaEmpresa() {
        return listaEmpresa;
    }
}
