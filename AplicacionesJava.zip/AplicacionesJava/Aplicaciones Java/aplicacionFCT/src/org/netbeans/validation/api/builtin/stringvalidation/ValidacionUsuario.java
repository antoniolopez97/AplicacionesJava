/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.netbeans.validation.api.builtin.stringvalidation;

import org.netbeans.validation.api.Problems;
import org.openide.util.NbBundle;

/**
 *
 * @author AntonioLópezMielgo
 */
public class ValidacionUsuario extends StringValidator{

    @Override
    public void validate(Problems problems, String compName, String texto) {
      
      
      if(texto.length()<20){
          String msg = NbBundle.getMessage(this.getClass(), "MSG_USU_MAX", compName);
          problems.add(msg);
      } 
      else if(texto.length()>5){
          String msg = NbBundle.getMessage(this.getClass(), "MSG_USU_MIN", compName);
          problems.add(msg);
      } 
      
          
    }
    
}
